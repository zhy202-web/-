import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, precision_score, recall_score
import urllib.request
import os

print("=" * 50)
print("1. 数据加载")
print("=" * 50)

url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00350/default%20of%20credit%20card%20clients.xls"
filename = "default_of_credit_card_clients.xls"

if not os.path.exists(filename):
    print("正在下载数据集...")
    urllib.request.urlretrieve(url, filename)
    print("下载完成！")

df = pd.read_excel(filename, header=1)
X = df.drop(['ID', 'default payment next month'], axis=1)
y = df['default payment next month'].astype(int)

print(f"数据集形状: {df.shape}")
print(f"违约率: {y.mean():.2%}")

# 数据划分
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 超参数搜索
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

grid_search = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=5, scoring='roc_auc', n_jobs=-1)
grid_search.fit(X_train_scaled, y_train)

# 最佳模型
rf_best = grid_search.best_estimator_
y_pred = rf_best.predict(X_test_scaled)
y_pred_proba = rf_best.predict_proba(X_test_scaled)[:, 1]

print("\n模型评估：")
print(f"准确率: {accuracy_score(y_test, y_pred):.4f}")
print(f"AUC: {roc_auc_score(y_test, y_pred_proba):.4f}")
print("\n✅ 数据 & 模型准备完成！")