"""
混淆矩阵与错误分析
"""

import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
print("=" * 60)
print("混淆矩阵与错误分析")
print("=" * 60)

# 使用之前训练好的模型 rf_best
y_pred = rf_best.predict(X_test_scaled)

# 混淆矩阵
cm = confusion_matrix(y_test, y_pred)

# 计算指标
tn, fp, fn, tp = cm.ravel()
print(f"真负例(TN): {tn}")
print(f"假正例(FP): {fp}")
print(f"假负例(FN): {fn}")
print(f"真正例(TP): {tp}")
print(f"\n准确率: {(tn+tp)/(tn+fp+fn+tp):.4f}")
print(f"精确率: {tp/(tp+fp):.4f}")
print(f"召回率: {tp/(tp+fn):.4f}")
print(f"F1分数: {2*tp/(2*tp+fp+fn):.4f}")

# 设置中文字体（避免乱码）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 绘制混淆矩阵
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['未违约', '违约'],
            yticklabels=['未违约', '违约'])
plt.xlabel('预测标签')
plt.ylabel('真实标签')
plt.title('随机森林混淆矩阵')
plt.tight_layout()
plt.savefig('confusion_matrix.png', dpi=300)
plt.show()
print("已保存: confusion_matrix.png")

# 分类报告
print("\n分类报告:")
print(classification_report(y_test, y_pred, target_names=['未违约', '违约']))

# 错误样本分析
error_mask = y_pred != y_test
error_indices = np.where(error_mask)[0]
print(f"\n错误样本数: {len(error_indices)}/{len(y_test)} ({len(error_indices)/len(y_test)*100:.2f}%)")

# 错误样本的群体分布
X_test_error = X_test.iloc[error_indices]
print("\n错误样本的群体分布:")
print(f"  女性: {(X_test_error['SEX'] == 2).sum()}/{len(X_test_error)} ({(X_test_error['SEX'] == 2).mean()*100:.1f}%)")
print(f"  男性: {(X_test_error['SEX'] == 1).sum()}/{len(X_test_error)} ({(X_test_error['SEX'] == 1).mean()*100:.1f}%)")
print(f"  青年(<30): {(X_test_error['AGE'] < 30).sum()}/{len(X_test_error)} ({(X_test_error['AGE'] < 30).mean()*100:.1f}%)")
print(f"  中年(30-50): {((X_test_error['AGE'] >= 30) & (X_test_error['AGE'] <= 50)).sum()}/{len(X_test_error)} ({((X_test_error['AGE'] >= 30) & (X_test_error['AGE'] <= 50)).mean()*100:.1f}%)")
print(f"  老年(>50): {(X_test_error['AGE'] > 50).sum()}/{len(X_test_error)} ({(X_test_error['AGE'] > 50).mean()*100:.1f}%)")
print(f"  低学历: {(X_test_error['EDUCATION'] <= 2).sum()}/{len(X_test_error)} ({(X_test_error['EDUCATION'] <= 2).mean()*100:.1f}%)")

print("\n✅ 混淆矩阵分析完成！")