import shap
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

print("=" * 50)
print("SHAP公平性分析")
print("=" * 50)

# 取500个样本
np.random.seed(42)
sample_idx = np.random.choice(len(X_test_scaled), 500, replace=False)
X_sample = X_test_scaled[sample_idx]
X_sample_original = X_test.iloc[sample_idx].copy()

# 计算SHAP值
print("计算SHAP值...")
explainer = shap.TreeExplainer(rf_best)
shap_values = explainer.shap_values(X_sample)

# 自动处理三维SHAP (样本, 特征, 类别)
print(f"原始SHAP形状: {shap_values.shape}")
if len(shap_values.shape) == 3:
    shap_values_class1 = shap_values[:,:,1]
elif isinstance(shap_values, list):
    shap_values_class1 = shap_values[1]
else:
    shap_values_class1 = shap_values

print(f"处理后SHAP形状: {shap_values_class1.shape}")

# ========== 1. 特征重要性 ==========
print("\n" + "=" * 50)
print("1. 特征重要性（Top 10）")
print("=" * 50)

feature_names = X.columns.tolist()
importance = np.abs(shap_values_class1).mean(axis=0)


top_indices = np.argsort(importance)[::-1][:10]
top_indices = [int(i) for i in top_indices]

for i, idx in enumerate(top_indices):
    print(f"{i+1}. {feature_names[idx]}: {importance[idx]:.6f}")

# ========== 2. 群体定义 ==========
print("\n" + "=" * 50)
print("2. 群体定义")
print("=" * 50)

def age_group(age):
    if age < 30:
        return '青年'
    elif age <= 50:
        return '中年'
    else:
        return '老年'

def edu_group(edu):
    if edu <= 2:
        return '低学历'
    elif edu == 3:
        return '中学历'
    else:
        return '高学历'

X_sample_original['AGE_GROUP'] = X_sample_original['AGE'].apply(age_group)
X_sample_original['EDU_GROUP'] = X_sample_original['EDUCATION'].apply(edu_group)
X_sample_original['SEX_GROUP'] = X_sample_original['SEX'].map({1: '男性', 2: '女性'})

print(f"女性: {(X_sample_original['SEX_GROUP'] == '女性').sum()}")
print(f"青年: {(X_sample_original['AGE_GROUP'] == '青年').sum()}")
print(f"低学历: {(X_sample_original['EDU_GROUP'] == '低学历').sum()}")

# ========== 3. 敏感属性分析 ==========
print("\n" + "=" * 50)
print("3. 敏感属性偏见分析")
print("=" * 50)

print("\n性别:")
for g in ['男性', '女性']:
    mask = (X_sample_original['SEX_GROUP'] == g).values
    if mask.sum() > 0:
        s = shap_values_class1[mask]
        print(f"  {g}: n={mask.sum():3d}, 均值={s.mean():+.4f}, 正比例={(s>0).mean():.1%}")

print("\n年龄:")
for g in ['青年', '中年', '老年']:
    mask = (X_sample_original['AGE_GROUP'] == g).values
    if mask.sum() > 0:
        s = shap_values_class1[mask]
        print(f"  {g}: n={mask.sum():3d}, 均值={s.mean():+.4f}, 正比例={(s>0).mean():.1%}")

print("\n教育:")
for g in ['低学历', '中学历', '高学历']:
    mask = (X_sample_original['EDU_GROUP'] == g).values
    if mask.sum() > 0:
        s = shap_values_class1[mask]
        print(f"  {g}: n={mask.sum():3d}, 均值={s.mean():+.4f}, 正比例={(s>0).mean():.1%}")

# ========== 4. 交叉群体分析 ==========
print("\n" + "=" * 50)
print("4. 交叉群体分析")
print("=" * 50)

# 初始化group列
X_sample_original['group'] = '其他'

# 定义交叉群体
low_edu_female = (X_sample_original['EDU_GROUP'] == '低学历') & (X_sample_original['SEX_GROUP'] == '女性')
low_edu_young = (X_sample_original['EDU_GROUP'] == '低学历') & (X_sample_original['AGE_GROUP'] == '青年')
female_young = (X_sample_original['SEX_GROUP'] == '女性') & (X_sample_original['AGE_GROUP'] == '青年')
all_three = low_edu_female & (X_sample_original['AGE_GROUP'] == '青年')
baseline = (X_sample_original['AGE_GROUP'] == '中年') & \
           (X_sample_original['EDU_GROUP'] == '中学历') & \
           (X_sample_original['SEX_GROUP'] == '男性')

X_sample_original.loc[baseline, 'group'] = '基准'
X_sample_original.loc[low_edu_female, 'group'] = '低学历+女性'
X_sample_original.loc[low_edu_young, 'group'] = '低学历+青年'
X_sample_original.loc[female_young, 'group'] = '女性+青年'
X_sample_original.loc[all_three, 'group'] = '低学历+女性+青年'

groups = ['基准', '低学历+女性', '低学历+青年', '女性+青年', '低学历+女性+青年']

print(f"{'群体':<20} {'样本量':<6} {'平均SHAP':<12} {'正比例':<8}")
print("-" * 55)

baseline_shap_mean = None
group_shap_means = {}

for g in groups:
    mask = (X_sample_original['group'] == g).values
    if mask.sum() > 0:
        s_mean = shap_values_class1[mask].mean()
        group_shap_means[g] = s_mean
        if g == '基准':
            baseline_shap_mean = s_mean
        print(f"{g:<20} {mask.sum():<6} {s_mean:+.4f}     {(shap_values_class1[mask]>0).mean():.1%}")

# ========== 5. ✅ 修复 t 检验：对【平均SHAP值】做检验 ==========
print("\n" + "=" * 50)
print("5. 统计显著性检验（vs基准群体）")
print("=" * 50)

for g in ['低学历+女性', '低学历+青年', '女性+青年', '低学历+女性+青年']:
    mask_g = (X_sample_original['group'] == g).values
    mask_b = (X_sample_original['group'] == '基准').values

    if mask_g.sum() > 0 and mask_b.sum() > 0:
        # 提取每个样本的平均SHAP值（标量）
        g_vals = shap_values_class1[mask_g].mean(axis=1)
        b_vals = shap_values_class1[mask_b].mean(axis=1)

        t_stat, p_val = stats.ttest_ind(g_vals, b_vals, equal_var=False)
        sig = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else "ns"
        print(f"{g}: t={t_stat:.2f}, p={p_val:.4f} {sig}")

# ========== 6. 可视化 ==========
print("\n" + "=" * 50)
print("6. 生成图表")
print("=" * 50)

# 图1：特征重要性
plt.figure(figsize=(10, 6))
top_feature_names = [feature_names[idx] for idx in top_indices[::-1]]
top_importance_values = [importance[idx] for idx in top_indices[::-1]]
plt.barh(top_feature_names, top_importance_values)
plt.xlabel('平均|SHAP值|')
plt.title('Top 10特征重要性')
plt.tight_layout()
plt.savefig('feature_importance.png', dpi=300)
plt.show()
print("已保存: feature_importance.png")

# 图2：SHAP摘要图
plt.figure(figsize=(12, 8))
shap.summary_plot(shap_values_class1, X_sample, feature_names=feature_names, show=False)
plt.tight_layout()
plt.savefig('shap_summary.png', dpi=300, bbox_inches='tight')
plt.show()
print("已保存: shap_summary.png")

print("\n✅ SHAP分析完成！")