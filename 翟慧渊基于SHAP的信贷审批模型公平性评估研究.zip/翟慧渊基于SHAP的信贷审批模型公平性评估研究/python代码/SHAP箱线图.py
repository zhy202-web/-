"""
交叉群体SHAP值箱线图可视化
"""
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
print("=" * 60)
print("交叉群体SHAP值箱线图")
print("=" * 60)

# 准备数据
box_data = []
box_labels = []
for g in groups:
    mask = (X_sample_original['group'] == g).values
    if mask.sum() > 0:
        # 把 (n, 23) 压成 (n*23,) 一维数组
        shap_flat = shap_values_class1[mask].flatten()
        box_data.append(shap_flat)
        box_labels.append(f"{g}\n(n={mask.sum()})")

# 绘制箱线图
plt.figure(figsize=(12, 6))
bp = plt.boxplot(box_data, labels=box_labels, patch_artist=True)
for patch in bp['boxes']:
    patch.set_facecolor('lightblue')

plt.axhline(y=0, color='red', linestyle='--', linewidth=1)
plt.ylabel('SHAP Value')
plt.title('Cross-group SHAP Value Distribution')
plt.xticks(rotation=15)
plt.tight_layout()
plt.savefig('shap_boxplot.png', dpi=300)
plt.show()

print("✅ 箱线图已保存：shap_boxplot.png")