"""
去偏方案对比：特征剔除 vs 样本重加权 vs 阈值调整
"""

from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

print("=" * 60)
print("去偏方案对比实验")
print("=" * 60)

# 定义不同去偏方案
strategies = {
    '原模型': {'remove': [], 'weight': None},
    '剔除性别': {'remove': ['SEX'], 'weight': None},
    '剔除性别+教育': {'remove': ['SEX', 'EDUCATION'], 'weight': None},
    '剔除性别+教育+年龄': {'remove': ['SEX', 'EDUCATION', 'AGE'], 'weight': None},
    '重加权(λ=0.8)': {'remove': [], 'weight': 0.8},
    '重加权(λ=0.6)': {'remove': [], 'weight': 0.6},
}

results = []

for name, strategy in strategies.items():
    # 特征剔除
    if strategy['remove']:
        keep_cols = [c for c in X.columns if c not in strategy['remove']]
        X_train_adj = X_train[keep_cols]
        X_test_adj = X_test[keep_cols]
        scaler_adj = StandardScaler()
        X_train_adj_scaled = scaler_adj.fit_transform(X_train_adj)
        X_test_adj_scaled = scaler_adj.transform(X_test_adj)
    else:
        X_train_adj_scaled = X_train_scaled
        X_test_adj_scaled = X_test_scaled

    # 训练模型
    rf_adj = RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42)

    # 样本重加权
    if strategy['weight'] is not None:
        # 为低学历样本降低权重
        sample_weight = np.ones(len(X_train_adj))
        low_edu_mask = X_train['EDUCATION'].isin([1, 2]) if not strategy['remove'] else X_train_adj['EDUCATION'].isin([1, 2])
        sample_weight[low_edu_mask] = strategy['weight']
        rf_adj.fit(X_train_adj_scaled, y_train, sample_weight=sample_weight)
    else:
        rf_adj.fit(X_train_adj_scaled, y_train)

    # 预测和评估
    y_pred_adj = rf_adj.predict(X_test_adj_scaled)
    acc = accuracy_score(y_test, y_pred_adj)

    # 计算人口均等差异（按性别）
    test_df = X_test.copy()
    test_df['pred'] = y_pred_adj
    male_acc = test_df[test_df['SEX'] == 1]['pred'].mean()
    female_acc = test_df[test_df['SEX'] == 2]['pred'].mean()
    dp_diff = abs(male_acc - female_acc)

    results.append({'方案': name, '准确率': acc, 'DP差异': dp_diff})
    print(f"{name}: 准确率={acc:.4f}, DP差异={dp_diff:.4f}")

# 汇总表格
print("\n" + "=" * 60)
print("去偏方案对比结果")
print("=" * 60)
results_df = pd.DataFrame(results)
print(results_df.to_string(index=False))

# 绘制帕累托前沿
plt.figure(figsize=(10, 6))
for _, row in results_df.iterrows():
    marker = 'o' if '剔除' in row['方案'] else 's' if '重加权' in row['方案'] else '^'
    plt.scatter(row['DP差异'], row['准确率'], s=150, marker=marker, label=row['方案'])
plt.xlabel('人口均等差异 (DP差异)')
plt.ylabel('准确率')
plt.title('公平性-准确率帕累托前沿')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('pareto_frontier.png', dpi=300)
plt.show()
print("已保存: pareto_frontier.png")