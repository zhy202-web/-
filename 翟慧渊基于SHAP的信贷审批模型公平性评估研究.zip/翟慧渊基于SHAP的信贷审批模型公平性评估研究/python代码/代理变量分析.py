"""
代理变量分析：非敏感属性能否预测敏感属性
"""

from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

print("=" * 60)
print("代理变量分析")
print("=" * 60)

# 预测性别（敏感属性）
X_train_proxy = X_train.drop(['SEX', 'AGE', 'EDUCATION'], axis=1)
X_test_proxy = X_test.drop(['SEX', 'AGE', 'EDUCATION'], axis=1)

scaler_proxy = StandardScaler()
X_train_proxy_scaled = scaler_proxy.fit_transform(X_train_proxy)
X_test_proxy_scaled = scaler_proxy.transform(X_test_proxy)

# 训练模型预测性别
rf_gender = RandomForestClassifier(n_estimators=100, random_state=42)
rf_gender.fit(X_train_proxy_scaled, (X_train['SEX'] == 2).astype(int))  # 1=女性
gender_pred = rf_gender.predict(X_test_proxy_scaled)
gender_true = (X_test['SEX'] == 2).astype(int)
gender_acc = accuracy_score(gender_true, gender_pred)
print(f"用非敏感属性预测性别准确率: {gender_acc:.4f} (随机猜测: 0.50)")

# 特征重要性分析（哪些非敏感属性泄露了性别）
feat_imp = rf_gender.feature_importances_
feat_names = X_train_proxy.columns
sorted_idx = np.argsort(feat_imp)[::-1][:10]

print("\n预测性别最重要的特征（代理变量）:")
for i, idx in enumerate(sorted_idx):
    print(f"  {i+1}. {feat_names[idx]}: {feat_imp[idx]:.4f}")

# 可视化
plt.figure(figsize=(10, 6))
plt.barh([feat_names[i] for i in sorted_idx[::-1]], [feat_imp[i] for i in sorted_idx[::-1]])
plt.xlabel('特征重要性')
plt.title('性别预测的特征重要性（代理变量）')
plt.tight_layout()
plt.savefig('proxy_analysis.png', dpi=300)
plt.show()
print("已保存: proxy_analysis.png")